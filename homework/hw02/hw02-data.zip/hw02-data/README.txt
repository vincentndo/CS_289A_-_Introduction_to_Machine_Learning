The 1D_poly_new.mat is for extra credit! See Piazza. Used the 1D_poly.mat file? It will also be accepted for full credit.
