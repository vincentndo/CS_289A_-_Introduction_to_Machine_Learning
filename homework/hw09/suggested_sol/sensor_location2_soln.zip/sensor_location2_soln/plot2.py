import numpy as np
import scipy.spatial
from starter import *
import matplotlib.pyplot as plt
from sklearn.preprocessing import PolynomialFeatures
# from sensor_location2_sol import *

def neural_network(X,Y,X_test,Y_test, num_neurons, activation):
    """
    This function performs neural network prediction.
    Input: 
    X: independent variables in training data.
    Y: dependent variables in training data.
    X_test: independent variables in test data.
    Y_test: dependent variables in test data.
    Output:
    mse: Mean square error on test data. 
    """
    # Normalize the data. 
    X_std = np.std(X, axis = 0)
    X_mean = np.mean(X, axis = 0)
    normalized_X = (X - X_mean)/X_std 
    Y_std = np.std(Y, axis = 0)
    Y_mean = np.mean(Y, axis = 0)
    normalized_Y = (Y - Y_mean)/Y_std     
    # Set up a neural network. 
    model = Model(normalized_X.shape[1])
    model.addLayer(DenseLayer(num_neurons,activation()))
    model.addLayer(DenseLayer(num_neurons,activation()))
    model.addLayer(DenseLayer(Y.shape[1],LinearActivation()))
    model.initialize(QuadraticCost())
    #print('W:\n'+str(model.layers[0].W))

    # Train the model and display the results
    #print('x:\n'+str(x))
    hist = model.train(normalized_X,normalized_Y,1000,GDOptimizer(eta=0.001))

    Y_pred = model.predict((X_test - X_mean)/X_std) # [n, k]
    Y_pred = Y_pred * Y_std + Y_mean
    mse = np.mean(np.sqrt(np.sum((Y_pred - Y_test)**2, axis = 1)))   
    return mse  

#############################################################################
#######################PLOT PART 2###########################################
#############################################################################
def generate_data(sensor_loc, k = 7, d = 2, 
                 n = 1, original_dist = True, noise = 1): 
    return generate_dataset(sensor_loc, num_sensors = k, spatial_dim = d, 
                 num_data = n, original_dist = original_dist, noise = noise)
np.random.seed(0)
n = 200
num_neuronss = np.arange(100,550,50)
mses = np.zeros((len(num_neuronss), 2))

# for s in range(replicates):
    
sensor_loc = generate_sensors()
X, Y = generate_data(sensor_loc, n = n) # X [n * 2] Y [n * 7] 
X_test, Y_test = generate_data(sensor_loc, n = 1000) 
for t,num_neurons in enumerate(num_neuronss):
    ### Neural Network:
    mse = neural_network(X, Y, X_test, Y_test, num_neurons, ReLUActivation)
    mses[t, 0] = mse

    mse = neural_network(X, Y, X_test, Y_test, num_neurons, TanhActivation)
    mses[t, 1] = mse
 
    # print('{}th Experiment with {} samples done...'.format(s, n))
    print('Experiment with {} neurons done...'.format(num_neurons))
        
### Plot MSE for each model. 
plt.figure()
activation_names = ['ReLU','Tanh']
for a in range(2):
    plt.plot(num_neuronss, mses[:,a], 
    	label = activation_names[a])
    
plt.title('Error on validation data verses number of neurons')
plt.xlabel('Number of neurons')
plt.ylabel('Average Error')
plt.legend(loc = 'best')
plt.yscale('log')
plt.savefig('num_neurons.png') 
    