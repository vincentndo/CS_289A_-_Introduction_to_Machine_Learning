import numpy as np
import scipy.spatial
from starter import *
import matplotlib.pyplot as plt
from sklearn.preprocessing import PolynomialFeatures
# from plot1 import * 
#############################################################################
#######################PLOT PART 1###########################################
#############################################################################
np.random.seed(0)
#ns = np.concatenate((np.arange(10,110,10), np.arange(200,1100,100)),axis = 0) 

ns = np.arange(100,310,50)
replicates = 1 
num_sets = 2
batchsizes = [20,50,None]

mses = np.zeros((len(ns), replicates, len(batchsizes), num_sets))
def generate_data(sensor_loc, k = 7, d = 2, 
                 n = 1, original_dist = True, noise = 1): 
    return generate_dataset(sensor_loc, num_sensors = k, spatial_dim = d, 
                 num_data = n, original_dist = original_dist, noise = noise)
def neural_network(X,Y,Xs_test,Ys_test, batchsize = 10):
    """
    This function performs neural network prediction.
    Input: 
    X: independent variables in training data.
    Y: dependent variables in training data.
    X_test: independent variables in test data.
    Y_test: dependent variables in test data.
    Output:
    mse: Mean square error on test data. 
    """
    # Normalize the data. 
    X_std = np.std(X, axis = 0)
    X_mean = np.mean(X, axis = 0)
    normalized_X = (X - X_mean)/X_std 

    Y_std = np.std(Y, axis = 0)
    Y_mean = np.mean(Y, axis = 0)
    normalized_Y = (Y - Y_mean)/Y_std  

    num_neurons = 141 
    activation = TanhActivation
    # Set up a neural network. 
    model = Model(normalized_X.shape[1])
    model.addLayer(DenseLayer(num_neurons,activation()))

    model.addLayer(DenseLayer(num_neurons,activation()))

    model.addLayer(DenseLayer(num_neurons,activation()))

    model.addLayer(DenseLayer(Y.shape[1],LinearActivation()))
    model.initialize(QuadraticCost())
    #print('W:\n'+str(model.layers[0].W))

    # Train the model and display the results
    #print('x:\n'+str(x))
    mses = []
    if batchsize is None:
        hist = model.train(normalized_X,normalized_Y,1000,GDOptimizer(eta=0.01))
    else:
        num_iters = int(n / batchsize) * 1000
        lr = 0.01 / int(n / batchsize)
        hist = model.trainBatch(normalized_X,normalized_Y, 
            batchsize, num_iters, GDOptimizer(eta=lr))

    for s, Y_test in enumerate(Ys_test):
        X_test = Xs_test[s]
        Y_pred = model.predict((X_test - X_mean)/X_std) # [n, k]

        Y_pred = Y_pred * Y_std + Y_mean
        mse = np.mean(np.sqrt(np.sum((Y_pred - Y_test)**2, axis = 1)))
        mses.append(mse)   
    return mse  

for s in range(replicates):
    sensor_loc = generate_sensors()
    X_test, Y_test = generate_data(sensor_loc, n = 1000) 
    for t,n in enumerate(ns):
        X, Y = generate_data(sensor_loc, n = n) # X [n * 2] Y [n * 7]
        Xs_test, Ys_test = [X, X_test], [Y, Y_test]  
        for k,batchsize in enumerate(batchsizes):
            ### Neural Network:
            mse = neural_network(X, Y, Xs_test, Ys_test)
            mses[t, s, k] = mse 
            print('{}th Experiment with {} samples and {} batchsize done...'.\
                format(s, n, batchsize))
        
### Plot MSE for each model. 
plt.figure()
names = ['Batchsize {}'.format(i) for i in batchsizes]
for a in range(len(batchsizes)):
    plt.plot(ns, np.mean(mses[:,:,a, 0], axis = 1), label = names[a])
    
plt.title('Error on training data for different batchsizes')
plt.xlabel('Number of training data')
plt.ylabel('Average Error')
plt.legend(loc = 'best')
plt.yscale('log')
plt.savefig('train_gd_sgd_mse.png')
# plt.show()    

plt.figure()
names = ['Batchsize {}'.format(i) for i in batchsizes]
for a in range(len(batchsizes)):
    plt.plot(ns, np.mean(mses[:,:,a, 1], axis = 1), label = names[a])
    
plt.title('Error on test data from the same distribution for different batchsizes')
plt.xlabel('Number of training data')
plt.ylabel('Average Error')
plt.legend(loc = 'best')
plt.yscale('log')
plt.savefig('val_gd_sgd_mse.png') 


