import numpy as np
import scipy.spatial 
from sklearn.preprocessing import PolynomialFeatures 
from starter import * 

#####################################################################
## Models used for predictions. 
##################################################################### 
def compute_update(single_obj_loc, sensor_loc, 
                                single_distance):
    """
    Compute the gradient of the loglikelihood function for part a.   
    
    Input:
    single_obj_loc: 1 * d numpy array. 
    Location of the single object.
    
    sensor_loc: k * d numpy array. 
    Location of sensor.
    
    single_distance: k dimensional numpy array. 
    Observed distance of the object.
    
    Output:
    grad: d-dimensional numpy array.
    
    """
    loc_difference = single_obj_loc - sensor_loc # k * d.
    phi = np.linalg.norm(loc_difference, axis = 1) # k. 
    grad = loc_difference / np.expand_dims(phi,1) # k * 2. 
    update = np.linalg.solve(grad.T.dot(grad),grad.T.dot(single_distance - phi)) #  2  

    return update

def get_object_location(sensor_loc, single_distance, num_iters = 20, num_repeats = 10):
    """
    Compute the gradient of the loglikelihood function for part a.   
    
    Input: 
    
    sensor_loc: k * d numpy array. Location of sensor.
    
    single_distance: k dimensional numpy array. 
    Observed distance of the object.
    
    Output:
    obj_loc: 1 * d numpy array. The mle for the location of the object.
    
    """   
    obj_locs = np.zeros((num_repeats, 1, 2)) 
    distances = np.zeros(num_repeats)
    for i in range(num_repeats):
        obj_loc = np.random.randn(1,2) * 100
        for t in range(num_iters):
            obj_loc += compute_update(obj_loc, sensor_loc, 
                                    single_distance)

        distances[i] = np.sum((single_distance - np.linalg.norm(obj_loc - sensor_loc, axis = 1))**2 )
        obj_locs[i] = obj_loc

    obj_loc = obj_locs[np.argmin(distances)]

    return obj_loc[0]

def generative_model(X,Y,Xs_test,Ys_test):
    """
    This function implements the generative model.
    Input: 
    X: independent variables in training data.
    Y: dependent variables in training data.
    Xs_test: independent variables in test data.
    Ys_test: dependent variables in test data.
    Output:
    mse: Mean square error on test data. 
    """
    initial_sensor_loc = np.random.randn(7,2) * 100
    estimated_sensor_loc = find_mle_by_grad_descent_part_e(initial_sensor_loc, 
               Y, X, lr=0.001, num_iters = 1000)

    mses = []
    for i, X_test in enumerate(Xs_test):
        Y_test = Ys_test[i]
        Y_pred = np.array([get_object_location(estimated_sensor_loc, X_test_single) \
            for X_test_single in X_test])
        #compute_distance_with_sensor_and_obj_loc(estimated_sensor_loc, X_test)
        mse = np.mean(np.sqrt(np.sum((Y_pred - Y_test)**2, axis = 1)))
        mses.append(mse)    
    return mses

def construct_second_order_data(X):
    """
    This function computes second order variables 
    for polynomial regression.
    Input:
    X: Independent variables.
    Output:
    A data matrix composed of both first and second order terms. 
    """
    X_second_order = []
    m = X.shape[1]
    for i in range(m):
        for j in range(m):
            if j <= i:
                X_second_order.append(X[:,i] * X[:,j])
    X_second_order = np.array(X_second_order).T
    return np.concatenate((X,X_second_order), axis = 1)

def linear_regression(X, Y, Xs_test, Ys_test):
    """
    This function performs linear regression.
    Input: 
    X: independent variables in training data.
    Y: dependent variables in training data.
    Xs_test: independent variables in test data.
    Ys_test: dependent variables in test data.
    Output:
    mse: Mean square error on test data. 
    """
    # Normalize the data. 
    X_std = np.std(X, axis = 0)
    X_mean = np.mean(X, axis = 0)

    normalized_X = (X - X_mean)/X_std
    # Add constant Term. 
    X_linear = np.concatenate((normalized_X, np.ones((len(X),1))), axis = 1)

    w = np.linalg.solve(X_linear.T.dot(X_linear),X_linear.T.dot(Y))

    mses = []
    for i, X_test in enumerate(Xs_test):
        Y_test = Ys_test[i]
        # Normalize the test data.
        X_linear_test = np.concatenate(((X_test - X_mean)/X_std,
                                        np.ones((len(X_test),1))), axis = 1)
        Y_pred = X_linear_test.dot(w)
        mse = np.mean(np.sqrt(np.sum((Y_pred - Y_test)**2, axis = 1))) 
        mses.append(mse)  
    return mses

def poly_regression_second(X,Y, Xs_test, Ys_test):
    """
    This function performs second order polynomial regression.
    Input: 
    X: independent variables in training data.
    Y: dependent variables in training data.
    Xs_test: independent variables in test data.
    Ys_test: dependent variables in test data.
    Output:
    mse: Mean square error on test data. 
    """
    X_second = construct_second_order_data(X)
    Xs_test_second = []
    for X_test in Xs_test:
        Xs_test_second.append(construct_second_order_data(X_test))

    mses = linear_regression(X_second,Y,Xs_test_second,Ys_test)
    return mses

def poly_regression_cubic(X,Y, Xs_test, Ys_test):
    """
    This function performs third order polynomial regression.
    Input: 
    X: independent variables in training data.
    Y: dependent variables in training data.
    Xs_test: independent variables in test data.
    Ys_test: dependent variables in test data.
    Output:
    mse: Mean square error on test data. 
    """
    poly = PolynomialFeatures(degree = 3)
    Xs_test_second = []
    X_third = poly.fit_transform(X)[:,1:] # Omit the constant terms
    Xs_test_third = []
    for X_test in Xs_test:
        Xs_test_third.append(poly.fit_transform(X_test)[:,1:]) # Omit the constant terms

    mses = linear_regression(X_third,Y,Xs_test_third,Ys_test)

    return mses

def neural_network(X,Y,Xs_test,Ys_test):
    """
    This function performs neural network prediction.
    Input: 
    X: independent variables in training data.
    Y: dependent variables in training data.
    Xs_test: independent variables in test data.
    Ys_test: dependent variables in test data.
    Output:
    mse: Mean square error on test data. 
    """
    # Normalize the data. 
    X_std = np.std(X, axis = 0)
    X_mean = np.mean(X, axis = 0)
    normalized_X = (X - X_mean)/X_std 

    Y_std = np.std(Y, axis = 0)
    Y_mean = np.mean(Y, axis = 0)
    normalized_Y = (Y - Y_mean)/Y_std 
    
    # Set up a neural network.
    activation = ReLUActivation
    model = Model(normalized_X.shape[1])
    model.addLayer(DenseLayer(100,activation()))
    model.addLayer(DenseLayer(100,activation()))
    model.addLayer(DenseLayer(Y.shape[1],LinearActivation()))
    model.initialize(QuadraticCost())
    #print('W:\n'+str(model.layers[0].W))

    # Train the model and display the results
    #print('x:\n'+str(x))
    hist = model.train(normalized_X,normalized_Y,1000,GDOptimizer(eta=0.01))
    mses = []
    for i, X_test in enumerate(Xs_test):
        Y_test = Ys_test[i]
        Y_pred = model.predict((X_test - X_mean)/X_std) # [n, k]
        Y_pred = Y_pred * Y_std + Y_mean
        mse = np.mean(np.sqrt(np.sum((Y_pred - Y_test)**2, axis = 1)) )   
        mses.append(mse)

    return mses 